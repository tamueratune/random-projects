import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Random;

//Abstract class
abstract public class Plant {
    private ImageIcon image;
    private Point pos;

    ImageIcon weed;


    //constructors
    public Plant() {
        weed = new ImageIcon();
        pos = new Point();
        int x = 0;
        int y = 0;

    }

    public Plant(int x, int y) {
        pos = new Point(x, y);
        weed = new ImageIcon("weed.png");

        ArrayList<String> imageArray = new ArrayList<String>();
        imageArray.add("flower0.png");
        imageArray.add("flower1.png");
        imageArray.add("flower2.png");
        imageArray.add("flower3.png");

        Random rand = new Random();
        int upperbound = 5-1;
        int int_random = rand.nextInt(upperbound);
        image = new ImageIcon(imageArray.get(int_random));
        //image = null;
        pos = new Point(x, y);


    }

    //Draw Method.
        // Draw Method for Weed .
    public void draw (Graphics a) {
        weed.paintIcon(null, a, pos.x, pos.y);
        //drawWeed(a,pos.x,pos.y, 40);
    }
    //Draw Method for flower.
    public void drawFlower (Graphics a) {
        //if statement (if the image is null then it will print the word Flower.
        if(image == null){
            a.setColor(Color.WHITE);
            a.drawString("Flower", pos.x, pos.y);

        }
        else {
            image.paintIcon(null, a, pos.x, pos.y);
            //drawFlower(a,pos.x,pos.y,40,Color.PINK);

        }


    }
    //extra credit Weed.
    public void drawWeed(Graphics a, int x, int y, int size){
        a.setColor(Color.GREEN.darker());
        a.fillRect(x + 2,y,5,70);
        a.fillRoundRect(x + 1,y + 5,20,10,200,200);
        a.fillRoundRect(x + 1,y + 40,20,10,200,200);
        a.fillRoundRect(x - 18,y + 25,20,10,200,200);


    }

    //extra credits construct for Drawing flowers.
    public static void drawFlower(Graphics a, int x, int y, int size, Color c){
        a.setColor(Color.GREEN.darker().darker());
        a.fillRect(x + 17,y + 20 ,7,50);

        a.setColor(c);
        a.fillOval(x,y,size/2,size/2);
        a.fillOval(x ,y + size/2 ,size/2,size/2);
        a.fillOval(x + size/2,y ,size/2,size/2);
        a.fillOval(x + size/2,y + size/2,size/2,size/2);

        a.setColor(Color.BLACK);
        a.fillOval(x + size/4, y+size/4, size/2, size/2);

    }

}
