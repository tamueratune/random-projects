import javax.swing.ImageIcon;
import java.awt.*;
import java.util.Random;
import java.util.ArrayList;


public class Flower extends Plant {
    //fields
    private ImageIcon image;
    private Point pos;


    //Constructors
    public Flower () {
        super();


    }
    public Flower(int x, int y){
        super(x,y);
    }

    public void draw (Graphics a){
        super.drawFlower(a);



    }
    //extra credits construct for Drawing flowers.
    public static void drawFlower(Graphics a, int x, int y, int size, Color c){
       /* a.setColor(Color.GREEN.darker().darker());
        a.fillRect(x + 17,y + 20 ,7,50);

        a.setColor(c);
        a.fillOval(x,y,size/2,size/2);
        a.fillOval(x ,y + size/2 ,size/2,size/2);
        a.fillOval(x + size/2,y ,size/2,size/2);
        a.fillOval(x + size/2,y + size/2,size/2,size/2);

        a.setColor(Color.BLACK);
        a.fillOval(x + size/4, y+size/4, size/2, size/2); */

    }



}
