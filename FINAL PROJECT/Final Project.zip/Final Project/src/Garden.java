import javax.swing.*;
import java.awt.*;


public class Garden {
    //fields
    private ImageIcon image;
    private Point pos;


    ImageIcon img,img1,img2,img3,img4,img5,img6,img7,img8,img9,img10,img11,img12,img13,img14,img15;


    public Garden (){
        //instantiating flower and weed.
        img = new ImageIcon("flower0.png");
        img1 = new ImageIcon("flower1.png");
        img2 = new ImageIcon("flower2.png");
        img3 = new ImageIcon("flower3.png");
        img4 = new ImageIcon( "weed.png");
        img5 = new ImageIcon("flower0.png");
        img6 = new ImageIcon("flower1.png");
        img7 = new ImageIcon("flower3.png");
        img8 = new ImageIcon("weed.png");
        img9 = new ImageIcon("flower0.png");
        img10 = new ImageIcon("flower1.png");
        img11 = new ImageIcon("flower0.png");
        img12 = new ImageIcon("flower3.png");
        img13 = new ImageIcon("flower0.png");




    }

    public void draw(Graphics a){
        //draw methods
        img.paintIcon(null,a, 100, 350);
        img1.paintIcon(null,a, 140, 450);
        img2.paintIcon(null,a, 180 , 350);
        img3.paintIcon(null,a, 220, 450);
        img4.paintIcon(null,a, 260, 350);
        img5.paintIcon(null,a, 300, 450);
        img6.paintIcon(null,a, 340, 350);
        img7.paintIcon(null,a, 380, 450);
        img8.paintIcon(null,a, 420, 350);
        img9.paintIcon(null,a, 460, 450);
        img10.paintIcon(null,a, 500, 350);
        img11.paintIcon(null,a, 540, 450);
        img12.paintIcon(null,a, 580, 350);
        img13.paintIcon(null,a, 620, 450);


      //Extra Credit (Draw Own Flowers & weed.
        /*drawFlower(a,100,350,40, Color.ORANGE);
        drawFlower(a,140,450,40, Color.RED);
        drawFlower(a,180,350,40, Color.GREEN);
        drawFlower(a,220,450,40, Color.YELLOW);
        drawFlower(a,260,350,40, Color.RED);
        drawFlower(a,300,450,40, Color.BLUE.brighter());
        drawFlower(a,340,350,40, Color.ORANGE);
        drawWeed(a,380,450, 40);
        drawFlower(a,420,350,40, Color.RED.darker());
        drawFlower(a,460,450,40, Color.PINK);
        drawWeed(a,500,350, 40);
        drawFlower(a,540,450,40, Color.BLUE);
        drawFlower(a,580,350,40, Color.ORANGE);
        drawFlower(a,620,450,40, Color.GREEN);
       // drawWeed(a,680,350, 40);
       // drawFlower(a,720,450,40, Color.YELLOW);
       */



    }
    //Extra Credit constructor for drawing flower.
    public static void drawFlower(Graphics a, int x, int y, int size, Color c){
        a.setColor(Color.GREEN.darker().darker());
        a.fillRect(x + 17,y + 20 ,7,50);

        a.setColor(c);
        a.fillOval(x,y,size/2,size/2);
        a.fillOval(x ,y + size/2 ,size/2,size/2);
        a.fillOval(x + size/2,y ,size/2,size/2);
        a.fillOval(x + size/2,y + size/2,size/2,size/2);

        a.setColor(Color.BLACK);
        a.fillOval(x + size/4, y+size/4, size/2, size/2);

    }
    //Extra Credit constructor for drawing weed.
    public void drawWeed(Graphics a, int x, int y, int size){
        a.setColor(Color.GREEN.darker());
        a.fillRect(x + 2,y,5,70);
        a.fillRoundRect(x + 1,y + 5,20,10,200,200);
        a.fillRoundRect(x + 1,y + 40,20,10,200,200);
        a.fillRoundRect(x - 18,y + 25,20,10,200,200);


    }
}
