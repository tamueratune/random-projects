import java.awt.*;
import java.util.ArrayList;
import java.util.Random;
import java.awt.Font;



public class MathProblem {
    //Fields
    private int num1;
    private int num2;
    private int num3;



    //Additional fields
    int answer;
    String operator = "?";




    public MathProblem(){

        Random rand = new Random();
        // number Arraylist for random number choosing.
        ArrayList<Integer> numArray = new ArrayList<>();
        numArray.add(1);
        numArray.add(2);
        numArray.add(3);
        numArray.add(4);
        numArray.add(5);
        numArray.add(6);
        numArray.add(7);
        numArray.add(8);
        numArray.add(9);
        numArray.add(10);
        numArray.add(11);
        numArray.add(12);
        numArray.add(13);

        // For loop/statement to randomly select from the arraylist.
       for (int i = 0; i < numArray.size(); ++i) {

           num1 = (int)(Math.random() * numArray.size());
           num2 = (int)(Math.random() * numArray.size());
       }
       // switch statement allows to randomly select between the cases of 0-3.
       switch (rand.nextInt(4)) {

           case 0: operator = "+";
            answer = num1 + num2;
            break;
            case 1: operator = "-";
            if ( num1 >=  num2){
                answer = num1 - num2;
                break;
            }

           case 2: operator = "\u00D7";
               answer = num1 * num2;
               break;

           case 3: operator = "\u00F7";
               if (num2 != 0 && num1 >= num2) {
                   answer = num1 / num2;
                    break;
               }
               else {

                   break;
               }

       }

    }
    // Draw Method.
    public void draw(Graphics a){
             a.setFont(new Font("serif", Font.PLAIN, 30));
            a.drawString(num1 + "  " +operator+ " " + num2 + " " + "="  /*+answer*/, 330, 250);


    }
}
